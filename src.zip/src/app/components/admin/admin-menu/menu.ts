export class Menu {
    menu_name:string='';
    menu_description:string='';
    menu_image:string='';
constructor(){
}
}
