export class Food {
    food_name:string='';
    food_description:string='';
    food_image:string='';
    food_id:number=0;
    price:number=0;
    category:string='';
}
