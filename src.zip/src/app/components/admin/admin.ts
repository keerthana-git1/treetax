export class Admin {
admin_id:number=0;
admin_name:string='';
admin_email:string='';
admin_password:string='';
constructor(){
}
}
