export class Customer {
    customer_id:number=0;
    customer_name:string='';
    customer_email:string='';
    customer_password:string='';
    customer_address:string='';
    constructor(){}

}
