export class Food {
    food_name:string='';
    food_description:string='';
    category:string='';
    price:number=0;
    food_image:string='';
}
